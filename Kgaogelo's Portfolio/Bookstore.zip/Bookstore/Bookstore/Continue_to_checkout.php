<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COMPLETED</title>
    <link rel ="stylesheet" href ="Css.css">
</head>
<body center, background="img/Water.jpg" link="#000">


    <p>THANK YOU FOR Shopping WITH US </p>
	
	
	<p> Go back to Login page: <a href="login.php"> Login</a></p>
</body>
</html>

<?php
// Generate a random order number
$orderNumber = generateOrderNumber();

// Function to generate a random order number
function generateOrderNumber() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $length = 8;
    $orderNumber = '';

    // Generate a random order number by selecting characters randomly from the given pool
    for ($i = 0; $i < $length; $i++) {
        $randomIndex = rand(0, strlen($characters) - 1);
        $orderNumber .= $characters[$randomIndex];
    }

    return $orderNumber;
}

// Check if the user clicked to order a book
if (isset($_POST['order'])) {
    // Perform the necessary actions to process the order

    // Display the order number to the user
    echo "Your order number is: $orderNumber";
}
?>

<!-- HTML form to trigger the order -->
<form method="post" action="">
    <input type="submit" name="order" value="View orderNumber">
</form>


