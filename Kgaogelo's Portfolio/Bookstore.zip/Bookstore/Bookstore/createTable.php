<?php

$tblusers = "CREATE TABLE `tblusers` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `stnum` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usertype` varchar(10) NOT NULL DEFAULT 'user',
  `vstatus` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1";

$tbladmin = "CREATE TABLE `tbladmin` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usertype` varchar(10) NOT NULL DEFAULT 'user',
  `vstatus` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1";

$tblbooks = "CREATE TABLE `tblbooks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1";

$tblorders = "CREATE TABLE `tblorders` (
  `oid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `orderdate` date NOT NULL,
  PRIMARY KEY (`oid`),
  CONSTRAINT `tblorders_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `tblusers` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$tblorderbooks = "CREATE TABLE `tblorderbooks` (
  `oid` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qnty` int(10) NOT NULL,
  PRIMARY KEY (`oid`,`id`),
  CONSTRAINT `tblorderbooks_ibfk_1` FOREIGN KEY (`id`) REFERENCES `tblbooks` (`id`),
  CONSTRAINT `tblorderbooks_ibfk_2` FOREIGN KEY (`oid`) REFERENCES `tblorders` (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$createTBLUsers = mysqli_query($conn,$tblusers);
$createTBLBooks = mysqli_query($conn,$tblbooks);
$createTBLOrders = mysqli_query($conn,$tblorders);
$createTBLOrderBooks = mysqli_query($conn,$tblorderbooks);

//Creating tables if they don't exist
if ($createTBLUsers && $createTBLBooks &&  $createTBLOrders && $createTBLOrderBooks) {
			
			//echo "<br>Tables created successfully<br>";
			
		} else {
			
			//echo "<br>Tables already exist<br>";
		}

		$query = "SELECT * FROM tblusers";

		$result = mysqli_query($conn,$query);
		
		if (mysqli_num_rows($result) == false) {
			
			InsertIntoUsers();
			InsertIntoBooks();
		}
		
		function InsertIntoUsers(){

				global $conn;

				$open = fopen('userData.txt','r');

				while (!feof($open)) 
					
					{
						$getTextLine = fgets($open);
						$explodeLine = explode(",",$getTextLine);

						list($fname,$stnum,$email,$pass,$lname) = $explodeLine;

						$qry = "insert into tblUsers
						(fname, lname, stnum, email, password) values('$fname','$lname','$stnum','$email','$pass')";
						mysqli_query($conn,$qry);
					}

				fclose($open);
				
				}
				
				function InsertIntoBooks(){

				global $conn;
				// Open the file for read access
				$open = fopen('bookData.txt','r');

				while (!feof($open)) // Loop thru file until the end
					
					{
						$getTextLine = fgets($open); //Get each line
						$explodeLine = explode(",",$getTextLine);

						list($name,$price,$image) = $explodeLine;

						$qry = "insert into tblbooks 
						(name,price,image) values ('$name','$price','$image')";
						mysqli_query($conn,$qry);
					}

				fclose($open);  
				}

?>