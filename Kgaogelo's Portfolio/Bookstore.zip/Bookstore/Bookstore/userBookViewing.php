<?php
 
	include "DBConn.php";
	include 'createTable.php'; 
	
	//Storing the data into database
	if(isset($_POST['add_to_cart'])){
		if(isset($_SESSION['cart'])){
			
			$session_array_id = array_column($_SESSION['cart'],"id");
			
			if(!in_array($_GET['id'], $session_array_id)){
				$session_array = array(
			   'id' => $_GET['id'],
			   "name" => $_POST['name'],
			   "price" => $_POST['price'],
			   "quantity" => $_POST['quantity']
			);
			
			$_SESSION['cart'][] = $session_array;
			}
		
	    }else{
			$session_array = array(
			   'id' => $_GET['id'],
			   "name" => $_POST['name'],
			   "price" => $_POST['price'],
			   "quantity" => $_POST['quantity']
			);
			
			$_SESSION['cart'][] = $session_array;
		}
	}
?>


<!DOCTYPE html> 
<html>
<head>
   <title>My School Books</title>
     
   <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
  <style>


    ul.menu {
      list-style-type: none;
      margin: 0;
      padding: 0;
      background-color: azure;
    }
    
    ul.menu li {
      display: inline-block;
    }
    
    ul.menu li a {
      display: block;
      padding: 10px 60px;
      text-decoration: none;
	  font-size: 22px;
      color:black;
    }
    
    ul.menu li a:hover {
      background-color: #ddd;
    }

	ul.h1 {text-align: center;}
	ul.h1 {background-color: white}
	
	
	ul.p{text-align: center}
	ul.p{background-color:orange}
	
	h2{text-align: center}
	
	ul.ff
	{ 
      background-color: green;
       padding: 10px;
       text-align: center;
     color: white;
    }

		</style>
</head>


<body style="background-color:#EEE2DE">

 <ul class="menu">
    <li><a href="login.php">Login</a></li>
	<li><a href="Admin.php">Admin</a></li>
    <li><a href="userBookViewing.php">Books</a></li>
    <li><a href="registration.php">Register</a></li>
	
  </ul>
  

   <div class="container-fluid">
      <div class="col-md-12">
	     <div class="row">
		    <div class="col-md-6">
			   <h2 class="text-center">Available Textbooks</h2>
			   <div class="col-md-12">
			      <div class="row">
				  
			     
			   
			   <?php
			   
			      $query = "SELECT * FROM tblbooks";
				  $result = mysqli_query($conn,$query);
				  
				  while($row = mysqli_fetch_assoc($result)){?>
				     <div class="col-md-4">
					  <form method="post" action="userBookViewing.php?id=<?=$row['id']?>">
					     <img src="img/<?=$row['image']?>" style='height: 150px;'>
						 <h5 class="text-center"><?=$row['name'];?></h5>
						 <h5 class="text-center">R<?=number_format($row['price'],2); ?></h5>
						 <input type="hidden" name="name" value="<?=$row['name'] ?>">
						 <input type="hidden" name="price" value="<?=$row['price'] ?>">
						 <input type="number" name="quantity" value="1" class="form-control">
						 <input type="submit" name="add_to_cart" class="btn btn-warning btn-block my-2" value="Add To Cart">
						 
					  </form>
				     </div>
					  
				  <?php }
			   
			   ?>
			     </div>
			   </div>
			   
            </div>
			<div class="col-md-6">
			   <h2 class="text-center">Books in cart</h2>
			   
			   
			   <?php 
			   
			   $total = 0;
			   
			   //Creating table to view data added to cart
			   
			      $output = "";
				  
				  $output = "
				    <table class='table table-bordered table-triped'>
					<tr>
					<th>BookID</th>
					<th></th>
					<th>Book Name</th>
					<th></th>
					<th>Price</th>
					<th>Action</th>
					<th>Quatity</th>
					<th></th>
					<th>Same Books Price</th>
					</tr>
				  ";
				  
				  if(!empty($_SESSION['cart'])){
					  foreach($_SESSION['cart'] as $key => $value){
						  
						  $output .="
						    <tr>
							<td>".$value['id']."<td/>
							<td>".$value['name']."<td/>
							<td>".$value['price']."<td/>
							<td>".$value['quantity']."<td/>
							<td>R".number_format($value['price'] * $value['quantity'],2)."<td/>
							<td>
							  <a href='userBookViewing.php?action=remove&id=".$value['id']."'>
							    <button class='btn btn-danger btn-block'>Remove</button>
							  </a>
							<td/>
						  ";
						  
						  $total = $total + $value['quantity'] * $value['price'];
						  
					  }
					  $output .="
					     <tr>
						   <td colspan='3'></td>
						   <td></b>All Books Total Price</b></td>
						   <td>".number_format($total,2)."</td>
						   <td>
		
						   </td>
						   
						 </tr>
					  ";
				  }
			   
			   echo $output;
			   ?>
		
			</div>
			
         </div>
      </div>
   </div>
   
   <?php
   
    //Code for clear all button
	  if(isset($_GET["actions"])){
		  
		  unset($_SESSION["cart"]);
		  
	  }
	//
	
	
   ?>
   <div class="checkout">
    <a href="Checkout.php">Checkout</a>
   </div>
 

</body>
</html>