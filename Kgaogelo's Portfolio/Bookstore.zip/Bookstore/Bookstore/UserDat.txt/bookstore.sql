-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 21, 2023 at 02:42 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

DROP TABLE IF EXISTS `tbladmin`;
CREATE TABLE IF NOT EXISTS `tbladmin` (
  `username` varchar(21) NOT NULL,
  `email` varchar(21) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`username`, `email`) VALUES
('', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooks`
--

DROP TABLE IF EXISTS `tblbooks`;
CREATE TABLE IF NOT EXISTS `tblbooks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooks`
--

INSERT INTO `tblbooks` (`id`, `name`, `price`, `image`) VALUES
(12, 'Advanced Mathematics 1', '320.20', 'AdvMaths1.jpg\r\n'),
(13, 'An introduction to IT', '234.30', 'IT.jpg\r\n'),
(14, 'Advanced Programming with Visual Basic', '330.00', 'AdvProgVB.jpg\r\n'),
(15, 'Teaching Chemistry', '290.90', 'TC.jpg\r\n'),
(16, 'System Analysis And Design', '210.23', 'SysAnalysis.jpg\r\n'),
(17, 'Engeneering Mathematics', '310.10', 'EM.jpg\r\n'),
(18, 'Python Programming', '350.25', 'PP.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblorderbooks`
--

DROP TABLE IF EXISTS `tblorderbooks`;
CREATE TABLE IF NOT EXISTS `tblorderbooks` (
  `oid` int NOT NULL,
  `id` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qnty` int NOT NULL,
  PRIMARY KEY (`oid`,`id`),
  KEY `tblorderbooks_ibfk_1` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblorders`
--

DROP TABLE IF EXISTS `tblorders`;
CREATE TABLE IF NOT EXISTS `tblorders` (
  `oid` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `orderdate` date NOT NULL,
  PRIMARY KEY (`oid`),
  KEY `tblorders_ibfk_1` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

DROP TABLE IF EXISTS `tblusers`;
CREATE TABLE IF NOT EXISTS `tblusers` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `stnum` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usertype` varchar(10) NOT NULL DEFAULT 'user',
  `vstatus` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`uid`, `fname`, `lname`, `stnum`, `email`, `password`, `usertype`, `vstatus`) VALUES
(51, 'kgaogelo', 'makgwale', 'st10187276', 'st10187276@rcconnect.edu.za', 'ffa2952b2fd638f2c3e651c44a7f8c83', 'user', b'1'),
(52, 'Mampshe', 'smith', 'st17884890', 'st17884890@rcconnect.edu.za', '3eb754c5fd5edaed177ab73d20c887d9', 'user', b'1'),
(53, 'kgao', 'mashabela', 'st1234567', 'st1234567@rcconnect.edu.za', '760fc47a6fe49ede0adbfbbc444e9074', 'user', b'1');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblorderbooks`
--
ALTER TABLE `tblorderbooks`
  ADD CONSTRAINT `tblorderbooks_ibfk_1` FOREIGN KEY (`id`) REFERENCES `tblbooks` (`id`),
  ADD CONSTRAINT `tblorderbooks_ibfk_2` FOREIGN KEY (`oid`) REFERENCES `tblorders` (`oid`);

--
-- Constraints for table `tblorders`
--
ALTER TABLE `tblorders`
  ADD CONSTRAINT `tblorders_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `tblusers` (`uid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
